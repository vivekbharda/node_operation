var userModel = require('../model/user.model');
let userController = {};

userController.addUser = function(req,res){
	var user = new userModel(req.body);
	user.save(function(err,savedUser){       
		console.log(err,savedUser);
		res.send(savedUser)
	})
	console.log(req.body);
}


userController.updateUser = function(req,res){

	var userid = req.body._id; //new userModel(req.body);
	userModel
	.findOneAndUpdate({_id: userid},req.body,{upsert:true},function(err,updatedUser){
		console.log(updatedUser);
		res.send(updatedUser);
	})
}


userController.deleteUser = function(req,res){
	var userid = req.body._id;
	userModel.remove({_id: userid}, function(err,removeuser){
		console.log(removeuser);
		res.send(removeuser);
	})
}


userController.getUserById = function(req,res){
	userModel.find({_id: req.params.id},function(err,foundUser){
		res.send(err || foundUser);
	})
}


userController.getUsers = function(req,res){
	userModel.find({},function(err,users){
		res.send({users:users});
	})
}



	


module.exports = userController;